package com.example.samuel.firstapp;

import android.Manifest;
import android.content.pm.PackageManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final TextView textExample = (TextView) findViewById(R.id.text_example);
        final TextView Text_msg = (TextView) findViewById(R.id.edit_example);
        final TextView Text_num = (TextView) findViewById(R.id.num_edit);

        Button botao_emergencia = (Button) findViewById(R.id.emergencia_msg_button);
        Button botao_fome = (Button) findViewById(R.id.fome_msg_button);
        Button botao_sede = (Button) findViewById(R.id.sede_msg_button);
        Button botao_num = (Button) findViewById(R.id.button_num);
        Button botao_send = (Button) findViewById(R.id.button_send);

        Text_num.setText("12982275931");

        final int PERMISSION_REQUEST_CODE = 1;

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {

            if (checkSelfPermission(Manifest.permission.SEND_SMS)
                    == PackageManager.PERMISSION_DENIED) {

                Log.d("permission", "permission denied to SEND_SMS - requesting it");
                String[] permissions = {Manifest.permission.SEND_SMS};

                requestPermissions(permissions, PERMISSION_REQUEST_CODE);

            }
        }




        botao_send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String text = Text_msg.getText().toString();
                String numero_tel = Text_num.getText().toString();

                //String numero_tel = "12981407501";
                //numero_tel = "12982275931";

                textExample.setText("Enviando a mensagem: \"" + text + "\" para o número: " + numero_tel);
                sendSMS(numero_tel, text);

            }
        });
        botao_emergencia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Text_msg.setText("Preciso de ajuda");

            }
        });

        botao_fome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Text_msg.setText("Estou com fome");


            }
        });
        botao_sede.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Text_msg.setText("Estou com sede");


            }
        });

    }


    private void sendSMS(String phoneNumber, String message) {
        SmsManager sms = SmsManager.getDefault();
        sms.sendTextMessage(phoneNumber, null, message, null, null);
    }


}