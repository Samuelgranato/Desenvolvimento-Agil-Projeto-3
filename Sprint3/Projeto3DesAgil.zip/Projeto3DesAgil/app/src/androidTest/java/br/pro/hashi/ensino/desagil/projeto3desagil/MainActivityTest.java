package br.pro.hashi.ensino.desagil.projeto3desagil;

import static org.junit.Assert.*;

public class MainActivityTest {

}