package br.pro.hashi.ensino.desagil.projeto3desagil;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Handler;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnLongClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Chronometer;
import java.util.ArrayList;
import java.util.LinkedList;

@SuppressLint("Registered")
public class MainActivity extends AppCompatActivity {
    @SuppressLint("ClickableViewAccessibility")
    ToneGenerator toneGenerator;
    public static Handler myHandler = new Handler();
    private static final int TIME_TO_WAIT = 1000;

    @SuppressLint("ClickableViewAccessibility")
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        final TextView textExample = (TextView) findViewById(R.id.text_example);
        final TextView Text_msg = (TextView) findViewById(R.id.edit_example);
        final TextView Text_num_sending = (TextView) findViewById(R.id.num_sending);
        final TextView text_morse = (TextView) findViewById(R.id.morse_txt);
        final TextView Text_nome_sending = (TextView) findViewById(R.id.nome_sending);
        final Button botao_mensagem = (Button) findViewById(R.id.msg_button);
        final int[] num_index = new int[1];
        final long[] time_out = new long[1];
        final int[] num_index_msg = new int[1];
        final String[] mensangem = new String[1];
        final String[] morse_aux = new String[1];
        final LinkedList<String> morse_word=new LinkedList();

        final Leitor leitor= new Leitor();



        final Handler handler = new Handler();

        final long time;

        Button traduzir = (Button) (Button) findViewById(R.id.morse_tr);
        Button botao_morse_space = (Button) (Button) findViewById(R.id.morse_sp);

        Button botao_morse_long = (Button) (Button) findViewById(R.id.morse_long);
        final Button botao_num = (Button) findViewById(R.id.button_num);
        final Button botao_send = (Button) findViewById(R.id.button_send);

        toneGenerator = new ToneGenerator(AudioManager.STREAM_MUSIC, ToneGenerator.MAX_VOLUME);

//        Text_num.setText("12982275931");



        num_index[0] = 0;
        final ArrayList<String> numero_list = new ArrayList<String>();
        final ArrayList<String> nome_contato_list = new ArrayList<String>();

        numero_list.add("12982275931");
        numero_list.add("11975000078");
        numero_list.add("11975491595");
        numero_list.add("11975393535");
        numero_list.add("11989891961");

        nome_contato_list.add("Samuel");
        nome_contato_list.add("Antonio");
        nome_contato_list.add("Francato");
        nome_contato_list.add("Delch");
        nome_contato_list.add("Francato");

        num_index_msg[0] = 0;
        final ArrayList<String> msg_list = new ArrayList<String>();

        msg_list.add("Estou com fome");
        msg_list.add("Estou com sede");
        msg_list.add("Preciso ir ao banheiro");
        msg_list.add("Queria dar uma volta");
        msg_list.add("Preciso de ajuda");


        Text_msg.setText(msg_list.get(num_index_msg[0]));
        botao_mensagem.setText(msg_list.get(num_index_msg[0]+1));


        Text_nome_sending.setText(nome_contato_list.get(num_index[0]));
        Text_num_sending.setText(numero_list.get(num_index[0]));
        botao_num.setText(nome_contato_list.get(num_index[0]+1));

        mensangem[0]="";

        final Runnable myRunnable = new Runnable() {
            @Override
            public void run() {
                char traduzido = leitor.Traduz();
                if(traduzido != ' '){
                    mensangem[0] += traduzido;
                    Text_msg.setText(mensangem[0]);
                }
                leitor.morse_letter = "";
                text_morse.setText(leitor.morse_letter);
            }
        };
        final Runnable myRunnable_space = new Runnable() {
            @Override
            public void run() {

                mensangem[0] += " ";
                Text_msg.setText(mensangem[0]);
                toneGenerator.startTone(ToneGenerator.TONE_CDMA_CONFIRM);
                SystemClock.sleep(150);
                toneGenerator.stopTone();

            }
        };


        final int PERMISSION_REQUEST_CODE = 1;

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {

            if (checkSelfPermission(Manifest.permission.SEND_SMS)
                    == PackageManager.PERMISSION_DENIED) {

                Log.d("permission", "permission denied to SEND_SMS - requesting it");
                String[] permissions = {Manifest.permission.SEND_SMS};

                requestPermissions(permissions, PERMISSION_REQUEST_CODE);

            }
        }


        botao_morse_space.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(mensangem[0].length()<=1){
                    mensangem[0] = "";
                    leitor.morse_letter = "";
                    text_morse.setText(leitor.morse_letter);
                    Text_msg.setText(msg_list.get(num_index_msg[0]));
                    myHandler.removeCallbacks(myRunnable_space);
                }else {
                    mensangem[0] = mensangem[0].substring(0, mensangem[0].length() - 1);
                    leitor.morse_letter = "";
                    text_morse.setText(leitor.morse_letter);
                    Text_msg.setText(mensangem[0]);
                    myHandler.removeCallbacks(myRunnable_space);
                    myHandler.postDelayed(myRunnable_space, TIME_TO_WAIT*2);
                }
            }

        });






        botao_morse_long.setOnTouchListener(new View.OnTouchListener() {
            long millis_start =0;
            long millis_end =0 ;
            @Override
            public boolean onTouch(View v, MotionEvent motionEvent) {


                switch (motionEvent.getAction()){

                    case MotionEvent.ACTION_DOWN: {

                        toneGenerator.startTone(ToneGenerator.TONE_CDMA_PRESSHOLDKEY_LITE);

                        millis_start = System.currentTimeMillis();


                        break;

                    }
                    case MotionEvent.ACTION_UP: {
                        toneGenerator.stopTone();


                        millis_end = System.currentTimeMillis();


                        long time_dif = millis_end-millis_start;

                        if(time_dif<380){
                            leitor.addPonto();

                        }else{
                            leitor.addBarra();

                        }

                        if( leitor.morse_letter.length()==5){
                            char traduzido = leitor.Traduz();
                            if(traduzido != ' '){
                                mensangem[0] += traduzido;
                                leitor.morse_letter="";
                                Text_msg.setText(mensangem[0]);
                            }else{
                                leitor.morse_letter="";
                            }
                        }

                        text_morse.setText(leitor.morse_letter);

                        time_out[0] = millis_end;

                        myHandler.removeCallbacks(myRunnable);
                        myHandler.postDelayed(myRunnable, TIME_TO_WAIT);
                        myHandler.removeCallbacks(myRunnable_space);
                        myHandler.postDelayed(myRunnable_space, TIME_TO_WAIT*2);


//                        handler.postDelayed(new Runnable(){
//
//                            @Override
//                            public void run(){
//                                char traduzido = leitor.Traduz();
//                                if(traduzido != ' '){
//                                    mensangem[0] += traduzido;
//                                    Text_msg.setText(mensangem[0]);
//                                }
//                                leitor.morse_letter = "";
//                                text_morse.setText(leitor.morse_letter);
//                            }
//                        }, 1000);

//                        handler.postDelayed(new Runnable(){
//                            @Override
//                            public void run(){
//                                if(mensangem[0].charAt(mensangem[0].length()-1) != ' '){
//                                    mensangem[0] += ' ';
//                                }
//                                Text_msg.setText(mensangem[0]);
//                            }
//                        }, 1000);

                    }
                }

                return false;
            }
        });








        botao_send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String text = Text_msg.getText().toString();
                String numero_tel = Text_num_sending.getText().toString();

                //String numero_tel = "12981407501";
                //numero_tel = "12982275931";

                Context context = getApplicationContext();
                CharSequence sending_text = "Enviando a mensagem para : " + nome_contato_list.get(num_index[0]);
                int duration = Toast.LENGTH_SHORT;

                sendSMS(numero_tel, text);
                Toast toast = Toast.makeText(context, sending_text, duration);
                toast.show();

            }

        });
        botao_num.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (num_index[0] <numero_list.size()-1){
                    num_index[0] +=1;
                }else{
                    num_index[0] = 0;
                }

                if (num_index[0]+1 <numero_list.size()){
                    botao_num.setText(nome_contato_list.get(num_index[0]+1));
                }else{
                    botao_num.setText(nome_contato_list.get(0));
                }


                Text_num_sending.setText(numero_list.get(num_index[0]));
                Text_nome_sending.setText(nome_contato_list.get(num_index[0]));

            }
        });
        botao_mensagem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (num_index_msg[0] <msg_list.size()-1){
                    num_index_msg[0] +=1;
                }else{
                    num_index_msg[0] = 0;
                }

                if (num_index_msg[0]+1 <msg_list.size()){
                    botao_mensagem.setText(msg_list.get(num_index_msg[0]+1));
                }else{
                    botao_mensagem.setText(msg_list.get(0));
                }


                Text_msg.setText(msg_list.get(num_index_msg[0]));
                //Text_nome_sending.setText(nome_contato_list.get(num_index[0]));

            }
        });
    }


    private void sendSMS(String phoneNumber, String message) {
        SmsManager sms = SmsManager.getDefault();
        sms.sendTextMessage(phoneNumber, null, message, null, null);
    }


}