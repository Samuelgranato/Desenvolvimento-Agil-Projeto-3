package br.pro.hashi.ensino.desagil.projeto3desagil;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Queue;

public class Translator {
    // ESTA CLASSE NÃO PODE SER MODIFICADA!
    private class Node {
        private char value;
        private Node parent;
        private Node leftChild;
        private Node rightChild;

        public Node() {
            this.value = ' ';
            this.parent = null;
            this.leftChild = null;
            this.rightChild = null;
        }
        public Node(char value) {
            this.value = value;
            this.parent = null;
            this.leftChild = null;
            this.rightChild = null;
        }

        public char getValue() {
            return value;
        }
        public Node getParent() {
            return parent;
        }
        public void setParent(Node parent) {
            this.parent = parent;
        }
        public Node getLeftChild() {
            return leftChild;
        }
        public void setLeftChild(Node leftChild) {
            this.leftChild = leftChild;
        }
        public Node getRightChild() {
            return rightChild;
        }
        public void setRightChild(Node rightChild) {
            this.rightChild = rightChild;
        }
    }


    // ESTE CONJUNTO DE ATRIBUTOS NÃO PODE SER MODIFICADO, OU
    // SEJA, NÃO É PERMITIDO ADICIONAR NEM REMOVER ATRIBUTOS!
    private Node root;
    private HashMap<Character, Node> map;


    // ESTE CONSTRUTOR DEVE SER PREENCHIDO DE ACORDO COM O ENUNCIADO!
    public Translator() {
        Queue<Node> queue = new LinkedList<>();

        this.root = new Node();
        this.map = new HashMap<Character, Node>();

        queue.add(root);


        char[] table = {' ','e','t','i','a','n','m','s','u','r','w','d','k','g','o','h','v','f',' ','l',' ','p','j','b','x','c','y','z','q',' ',' ','5','4',' ','3',' ',' ',' ','2',' ',' ','+',' ',' ',' ',' ','1','6','=','/',' ',' ',' ',' ',' ','7',' ',' ',' ','8',' ','9','0'};

        for(int i = 0; i < table.length ; i++){
            Node node = queue.poll();
            node.value = table[i];
            this.map.put(table[i],node);

            Node left = new Node();
            Node right = new Node();

            node.setLeftChild(left);
            node.setRightChild(right);

            left.setParent(node);
            right.setParent(node);

            queue.add(left);
            queue.add(right);

        }

    }


    // ESTE MÉTODO DEVE SER PREENCHIDO DE ACORDO COM O ENUNCIADO!
    public char morseToChar(String code) {
        Node node = root;

        for(int i = 0; i<code.length();i++){
            if (code.charAt(i) == '.'){
                node = node.getLeftChild();
            }else{
                node = node.getRightChild();
            }

        }

        return node.getValue();
    }


    // ESTE MÉTODO DEVE SER PREENCHIDO DE ACORDO COM O ENUNCIADO!
    public String charToMorse(char c) {
        Node node;
        Node node_father;
        String morse = "";


        HashMap map2 = map;
        node = map.get(c);

        node_father = node.getParent();
        String feifj = "";


        while(node.getParent() != null){
            if(node == node_father.getLeftChild()){
                morse = '.' + morse;

            }else if (node == node_father.getRightChild()){
                morse = '-' + morse;
            }

            node = node_father;
            node_father = node.getParent();
        }


        return morse;
    }


    // ESTE MÉTODO DEVE SER PREENCHIDO DE ACORDO COM O ENUNCIADO!
    public LinkedList<String> getCodes() {
        LinkedList<String> codes = new LinkedList<>();
        Queue<Node> queue = new LinkedList<>();
        queue.add(root);


        while(!queue.isEmpty()){
            Node node = queue.poll();

            if(node.getLeftChild() != null){
                queue.add(node.getLeftChild());


            }
             if(node.getRightChild() != null){
                queue.add(node.getRightChild());


            }

            if(node.getValue()!=' '){
                codes.add(this.charToMorse(node.getValue()));
            }


        }


        return codes;
    }
}
