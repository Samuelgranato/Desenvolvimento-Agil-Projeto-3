package br.pro.hashi.ensino.desagil.projeto3desagil;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;

public class Leitor {
    private Translator translator;

    public LinkedList<String> morse_word = new LinkedList();

    public String morse_letter = "";


    public Leitor() {
        translator = new Translator();
    }

    public String addPonto() {
        morse_letter += '.';
        return morse_letter;
    }

    public String addBarra() {

        morse_letter += '-';
        return morse_letter;
    }

    public void addWord() {

        morse_word.add(morse_letter);
        morse_letter = "";
    }


    public char Traduz() {
        char traduzido = translator.morseToChar(morse_letter);
        return traduzido;

    }
}

