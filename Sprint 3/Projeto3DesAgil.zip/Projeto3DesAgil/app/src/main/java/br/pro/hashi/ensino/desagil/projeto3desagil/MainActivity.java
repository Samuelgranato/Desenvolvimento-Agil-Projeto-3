package br.pro.hashi.ensino.desagil.projeto3desagil;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

@SuppressLint("Registered")
public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // vfef
        final TextView textExample = (TextView) findViewById(R.id.text_example);
        final TextView Text_msg = (TextView) findViewById(R.id.edit_example);
        final TextView Text_num_sending = (TextView) findViewById(R.id.num_sending);
        final TextView Text_nome_sending = (TextView) findViewById(R.id.nome_sending);
        final int[] num_index = new int[1];
        final int[] num_index_msg = new int[1];
        final Button botao_mensagem = (Button) findViewById(R.id.msg_button);

        final Button botao_num = (Button) findViewById(R.id.button_num);
        final Button botao_send = (Button) findViewById(R.id.button_send);


//        Text_num.setText("12982275931");





        num_index[0] = 0;
        final ArrayList<String> numero_list = new ArrayList<String>();
        final ArrayList<String> nome_contato_list = new ArrayList<String>();

        numero_list.add("12982275931");
        numero_list.add("11975000078");
        numero_list.add("11975491595");
        numero_list.add("11975393535");
        numero_list.add("11989891961");

        nome_contato_list.add("Samuel");
        nome_contato_list.add("Antonio");
        nome_contato_list.add("Francato");
        nome_contato_list.add("Delch");
        nome_contato_list.add("Francato");

        num_index_msg[0] = 0;
        final ArrayList<String> msg_list = new ArrayList<String>();

        msg_list.add("Estou com fome");
        msg_list.add("Estou com sede");
        msg_list.add("Preciso ir ao banheiro");
        msg_list.add("Queria dar uma volta");
        msg_list.add("Preciso de ajuda");


//        botao_mensagem.setText(msg_list.get(num_index_msg[0]));
//        Text_msg.setText(msg_list.get(num_index_msg[0]+1));


        final int PERMISSION_REQUEST_CODE = 1;

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {

            if (checkSelfPermission(Manifest.permission.SEND_SMS)
                    == PackageManager.PERMISSION_DENIED) {

                Log.d("permission", "permission denied to SEND_SMS - requesting it");
                String[] permissions = {Manifest.permission.SEND_SMS};

                requestPermissions(permissions, PERMISSION_REQUEST_CODE);

            }
        }




        botao_send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String text = Text_msg.getText().toString();
                String numero_tel = Text_num_sending.getText().toString();

                //String numero_tel = "12981407501";
                //numero_tel = "12982275931";

                Context context = getApplicationContext();
                CharSequence sending_text = "Enviando a mensagem para : " + nome_contato_list.get(num_index[0]);
                int duration = Toast.LENGTH_SHORT;

                if (Text_msg.getText() !=  msg_list.get(num_index_msg[0])){
                    Toast toast = Toast.makeText(context, "Mensagem ou número não selecionados", duration);
                    toast.show();
                }else {
                    Toast toast = Toast.makeText(context, sending_text, duration);
                    toast.show();
                    sendSMS(numero_tel, text);
                }


//                textExample.setText("Enviando a mensagem: \"" + text + "\" para o número: " + numero_tel);


            }

        });
        botao_num.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                    if (num_index[0] <numero_list.size()-1){
                        num_index[0] +=1;
                    }else{
                        num_index[0] = 0;
                    }

                if (num_index[0]+1 <numero_list.size()){
                    botao_num.setText(nome_contato_list.get(num_index[0]+1));
                }else{
                    botao_num.setText(nome_contato_list.get(0));
                }


                Text_num_sending.setText(numero_list.get(num_index[0]));
                Text_nome_sending.setText(nome_contato_list.get(num_index[0]));

            }
        });
        botao_mensagem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (num_index_msg[0] <msg_list.size()-1){
                    num_index_msg[0] +=1;
                }else{
                    num_index_msg[0] = 0;
                }

                if (num_index_msg[0]+1 <msg_list.size()){
                    botao_mensagem.setText(msg_list.get(num_index_msg[0]+1));
                }else{
                    botao_mensagem.setText(msg_list.get(0));
                }


                Text_msg.setText(msg_list.get(num_index_msg[0]));
                //Text_nome_sending.setText(nome_contato_list.get(num_index[0]));

            }
        });

    }


    private void sendSMS(String phoneNumber, String message) {
        SmsManager sms = SmsManager.getDefault();
        sms.sendTextMessage(phoneNumber, null, message, null, null);
    }


}